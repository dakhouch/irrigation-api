import express from 'express';
import cookieParser from 'cookie-parser';
import logger from 'morgan';
import puitRouter from './routes/puitRoutes.mjs';
import courantRoutes from './routes/courantRoutes.mjs';
import secteurRouter from './routes/secteurRoutes.mjs';
import cors from "cors";
import stateRoutes from "./routes/stateRoutes.mjs";
import authentificationRoutes from "./routes/authentificationRoutes.mjs";

let app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cors());
app.use('/puits', puitRouter)
app.use('/secteurs',secteurRouter)
app.use('/courants',courantRoutes)
app.use('/state',stateRoutes)
app.use('/',authentificationRoutes)
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
